defineClass('FLRootViewController', {
    createLive: function() {
        NSLog("%s", __func__);
    },
});